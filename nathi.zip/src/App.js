import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import MainRoute from './router';

function App() {
  return (
    <div className="App">
      <MainRoute/>
    </div>
  );
}

export default App;
